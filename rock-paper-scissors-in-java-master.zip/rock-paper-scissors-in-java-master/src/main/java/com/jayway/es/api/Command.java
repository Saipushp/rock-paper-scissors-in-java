package com.jayway.es.api;

import java.util.UUID;

public interface Command {
	UUID aggregateId();
}
