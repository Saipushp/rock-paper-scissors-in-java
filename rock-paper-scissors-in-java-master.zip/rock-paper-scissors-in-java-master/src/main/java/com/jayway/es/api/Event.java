package com.jayway.es.api;

public interface Event {

}
