## Rock Paper Scissor server in Java using custom event system and Jersey

This is simple Rock Paper Scissor server implemented in Java. It's meant to be a testbed for new technologies.

## Endpoints

A simple REST interface is exposed on [http://localhost:8080/games].


Licensed under the [MIT license](https://opensource.org/licenses/MIT).
